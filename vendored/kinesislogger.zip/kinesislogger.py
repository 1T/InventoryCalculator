from logging import Filter, Logger, LogRecord
from os import getenv
from random import choice
from json import loads

from boto3 import client as boto3_client

STREAM_REGION = getenv('AWS_REGION', 'us-east-1')
STREAM_NAME_BASE = 'kinesis-logging-stream'
CROSS_ACCOUNT_LOGGING_ROLE_ARN = f'arn:aws:iam::405028608951:role/{STREAM_REGION}-LoggingCrossAccount'
APP_NAME = getenv('APP_NAME', 'unnamed')
IS_PROD = getenv('ENV_TYPE', 'dev') == 'prod'

# Assume cross account logging role
STS = boto3_client('sts')
ACCESS_CREDENTIALS = STS.assume_role(
    RoleArn=CROSS_ACCOUNT_LOGGING_ROLE_ARN,
    RoleSessionName=APP_NAME
)['Credentials']

# Instantiate firehose client with access credentials for cross account role
FIREHOSE_CLIENT = boto3_client(
    'firehose', region_name=STREAM_REGION, aws_access_key_id=ACCESS_CREDENTIALS['AccessKeyId'],
    aws_secret_access_key=ACCESS_CREDENTIALS['SecretAccessKey'],
    aws_session_token=ACCESS_CREDENTIALS['SessionToken']
)

# Get list of active kinesis logging streams
STREAMS = [
    stream for stream in FIREHOSE_CLIENT.list_delivery_streams()['DeliveryStreamNames']
    if STREAM_NAME_BASE in stream
]


class KinesisHandler(Logger):
    def __init__(self):
        super(KinesisHandler, self).__init__('kinesis-handler')
        self.level = None
        self.formatter = None
        self.filters = []

    def setLevel(self, level):
        self.level = level

    def setFormatter(self, formatter):
        self.formatter = formatter

    def addFilter(self, filter):
        self.filters.append(filter)

    def handle(self, record: LogRecord):
        """Send record to Firehose stream."""
        if not all([f.filter(record) for f in self.filters]):
            return
        record = self.formatter.format(record)
        if IS_PROD:
            # Send to Firehose stream if in production
            try:
                FIREHOSE_CLIENT.put_record(
                    Record={'Data': record},
                    DeliveryStreamName=choice(STREAMS)
                )
            except Exception as exc:
                print(exc)
        else:
            # Print message to Cloudwatch if in development
            print(loads(record)['message'])


class AppNameFilter(Filter):
    def filter(self, record):
        record.app_name = APP_NAME
        return True


LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'jsonformatter': {
            '()': 'pythonjsonlogger.jsonlogger.JsonFormatter',
            'fmt':
                '[%(levelname)s]\t%(asctime)s.%(msecs)dZ'
                '\t%(aws_request_id)s\t%(message)s\t%(app_name)s\n',
            'datefmt': '%Y-%m-%dT%H:%M:%S',
        }
    },
    'filters': {
        'requestid': {
            '()': '__main__.LambdaLoggerFilter',
        },
        'appname': {
            '()': 'kinesislogger.AppNameFilter',
        }
    },
    'handlers': {
        'kinesis-handler': {
            'class': 'kinesislogger.KinesisHandler',
            'filters': ['requestid', 'appname'],
            'formatter': 'jsonformatter',
            'level': 'INFO',
        },
    },
    'loggers': {
        '': {
            'level': 'WARNING'
        },
        APP_NAME: {
            'level': 'INFO',
            'handlers': ['kinesis-handler'],
            # required to avoid double logging with root logger
            'propagate': False
        },
        'boto3': {
            'level': 'ERROR'
        },
        'botocore': {
            'level': 'ERROR'
        }
    },
}
